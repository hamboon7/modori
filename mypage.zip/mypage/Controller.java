package com.modori.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Controller")
public class Controller extends HttpServlet {
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 1. cmd값 여부 체크 : 절대 안바뀜
		String cmd = request.getParameter("cmd");
		if(cmd==null || cmd.trim().length()<=5)
			cmd="index";
		String page = "";
		// 2. Factory(분배역할) and Action()
		Action a = null;
		switch(cmd) {
		case "loginUI":
			page="login.jsp";
			break;
		case "loginAction":
			a = new LoginAction();
			page = a.execute(request);
			break;
		case "logoutAction":
			a = new LogoutAction();
			page = a.execute(request);
			break;
		case "mainAction":
			a = new MainAction();
			page = a.execute(request);
			break;
		case "myPageUI":
			page="myPage.jsp";
			break;
		case "myPageAction":
			a = new MyPageAction();
			page = a.execute(request);
			break;
		case "memberUI":
			page="login.jsp";
			break;
		case "memberAction":
			a = new MemberAction();
			page = a.execute(request);
			break;
		case "findUI":
			page = "find.jsp";
			break;
		case "findAction":
			a = new FindAction();
			page = a.execute(request);
			break;
		case "findUpdateAction":
			a = new FindUpdateAction();
			page = a.execute(request);
			break;
		case "findUpdate2Action":
			a = new FindUpdate2Action();
			page = a.execute(request);
			break;
		case "searchAction":
			a = new SearchAction();
			page = a.execute(request);
			break;
		case "purchaseUI":
			page="purchase.jsp";
			break;
		case "purchaseAction":
			a = new PurchaseAction();
			page = a.execute(request);
			break;
		case "productUI":
			page="product.jsp";
			break;
		case "productAction":
			a = new ProductAction();
			page = a.execute(request);
			break;
		case "enrollUI":
			page="enroll.jsp";
			break;
		case "enrollAction":
			a = new EnrollAction();
			page = a.execute(request);
			break;
		case "productPurchaseUI":
			page="productPurchase.jsp";
			break;
		case "productPurchaseAction":
			a = new ProductPurchaseAction();
			page = a.execute(request);
			break;
		case "bazaarUI":
			page="bazaar.jsp";
			break;
		case "bazaarAction":
			a = new BazaarAction();
			page = a.execute(request);
			break;
		case "bazaarEnrollUI":
			page="bazaarEnroll.jsp";
			break;
		case "bazaarEnrollAction":
			a = new BazaarEnrollAction();
			page = a.execute(request);
			break;
		case "bazaarPurchaseUI":
			page="bazaarPurchase.jsp";
			break;
		case "bazaarPurchaseAction":
			a = new BazaarPurchaseAction();
			page = a.execute(request);
			break;
		case "auctionUI":
			page="auction.jsp";
			break;
		case "auctionAction":
			a = new AuctionAction();
			page = a.execute(request);
			break;
		case "auctionEnrollUI":
			page="auctionEnroll.jsp";
			break;
		case "auctionEnrollAction":
			a = new AuctionEnrollAction();
			page = a.execute(request);
			break;
		case "auctionPurchaseUI":
			page="auctionPurchase.jsp";
			break;
		case "auctionPurchaseAction":
			a = new AuctionPurchaseAction();
			page = a.execute(request);
			break;
		case "groupBuyingUI":
			page="groupBuying.jsp";
			break;
		case "groupBuyingAction":
			a = new GroupBuyingAction();
			page = a.execute(request);
			break;
		case "groupBuyingEnrollUI":
			page="groupBuyingEnroll.jsp";
			break;
		case "groupBuyingEnrollAction":
			a = new GroupBuyingEnrollAction();
			page = a.execute(request);
			break;
		case "groupPurchaseUI":
			page="groupPurchase.jsp";
			break;
		case "groupPurchaseAction":
			a = new GroupPurchaseAction();
			page = a.execute(request);
			break;
		case "index":
		default:
			page = "index.jsp";
			break;
		}
		// 3. View 페이지 이동 : 절대 안바뀜
		request.getRequestDispatcher("/"+page).forward(request, response);
	}
}
