package com.modori.model;

public class StudentCouncilBazaarCountVO {
	private int count1;
	private int sum1;
	private int count2;
	private int sum2;
	private int count3;
	private int sum3;
	private int count4;
	private int sum4;
	private int count5;
	private int sum5;
	private int count6;
	private int sum6;

	public StudentCouncilBazaarCountVO(int count1, int sum1, int count2, int sum2, int count3, int sum3, int count4,
			int sum4, int count5, int sum5, int count6, int sum6) {
		this.count1 = count1;
		this.sum1 = sum1;
		this.count2 = count2;
		this.sum2 = sum2;
		this.count3 = count3;
		this.sum3 = sum3;
		this.count4 = count4;
		this.sum4 = sum4;
		this.count5 = count5;
		this.sum5 = sum5;
		this.count6 = count6;
		this.sum6 = sum6;
	}

	public int getCount1() {
		return this.count1;
	}

	public void setCount1(int count1) {
		this.count1 = count1;
	}

	public int getSum1() {
		return this.sum1;
	}

	public void setSum1(int sum1) {
		this.sum1 = sum1;
	}

	public int getCount2() {
		return this.count2;
	}

	public void setCount2(int count2) {
		this.count2 = count2;
	}

	public int getSum2() {
		return this.sum2;
	}

	public void setSum2(int sum2) {
		this.sum2 = sum2;
	}

	public int getCount3() {
		return this.count3;
	}

	public void setCount3(int count3) {
		this.count3 = count3;
	}

	public int getSum3() {
		return this.sum3;
	}

	public void setSum3(int sum3) {
		this.sum3 = sum3;
	}

	public int getCount4() {
		return this.count4;
	}

	public void setCount4(int count4) {
		this.count4 = count4;
	}

	public int getSum4() {
		return this.sum4;
	}

	public void setSum4(int sum4) {
		this.sum4 = sum4;
	}

	public int getCount5() {
		return this.count5;
	}

	public void setCount5(int count5) {
		this.count5 = count5;
	}

	public int getSum5() {
		return this.sum5;
	}

	public void setSum5(int sum5) {
		this.sum5 = sum5;
	}

	public int getCount6() {
		return this.count6;
	}

	public void setCount6(int count6) {
		this.count6 = count6;
	}

	public int getSum6() {
		return this.sum6;
	}

	public void setSum6(int sum6) {
		this.sum6 = sum6;
	}

	public String toString() {
		return "count1=" + this.count1 + ", sum1=" + this.sum1 + ", count2=" + this.count2 + ", sum2=" + this.sum2
				+ ", count3=" + this.count3 + ", sum3=" + this.sum3 + ", count4=" + this.count4 + ", sum4=" + this.sum4
				+ ", count5=" + this.count5 + ", sum5=" + this.sum5 + ", count6=" + this.count6 + ", sum6=" + this.sum6;
	}
}